package com.yellow.group.petapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    private static final String Tag = "LoginActivity";
    private FirebaseAuth mAuth;
    //global variables for strings and field elements created-Brian
    String email, password;
    EditText etRegEmail,etRegPassword;

    @Override
    //check if user is logged in
    public void onStart() {
        super.onStart();
        // Check if user is signed in and update UI accordingly
        FirebaseUser currentUser = mAuth.getCurrentUser();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //elements needed to be initialzed in order to use the getText method-Brian
        etRegEmail = (EditText)findViewById(R.id.etRegEmail);
        etRegPassword = (EditText)findViewById(R.id.etRegPassword);

        mAuth = FirebaseAuth.getInstance();

        Button btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //these need to be defined in onclick to pull user info-B
                email = etRegEmail.getText().toString();// also needed getText to pass info-Brian
                password = etRegPassword.getText().toString();
                // needs error handling for password being less than 6 characters-Brian
                if(email.isEmpty() || password.isEmpty()){
                    Toast.makeText(RegisterActivity.this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
                } else if (password.length() < 6){
                    Toast.makeText(RegisterActivity.this, "Password must contain 6 characters.", Toast.LENGTH_SHORT).show();
                }else {
                    createAccount(email, password);
                }

            }
        });


    }

    void createAccount(final String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() { // just this was causing errors, needed to be specific with activity -B
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(Tag, "createUserWithEmail:success");
                            FirebaseDatabase.getInstance().getReference().child("users").child(task.getResult().getUser().getUid()).child("email").setValue(email);
                            Toast.makeText(RegisterActivity.this, "Registration succesful.", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this,HomeActivity.class ));
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(Tag, "createUserWithEmail:failure", task.getException());
                            Toast.makeText(RegisterActivity.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                        }

                        // ...
                    }
                });
    }

}