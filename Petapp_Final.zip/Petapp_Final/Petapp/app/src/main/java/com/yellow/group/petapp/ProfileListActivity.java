package com.yellow.group.petapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;




import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ProfileListActivity extends AppCompatActivity {

    //declare variables-Brian
    private ListView petProfilesListView;
    private ArrayList<String> pets = new ArrayList<>();
    private ArrayList<String> keys = new ArrayList<>();//an array list to keep track of the current pet uid-Brian
    private ArrayAdapter adapter;
    private String uid, petName, name, key;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_list);

        //get the current user's id number-Brian
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();

        petProfilesListView = (ListView) findViewById(R.id.lvPets);
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, pets);
        petProfilesListView.setAdapter(adapter);

        //set an addChildEventListener on the children of the pets node to update the list activity when a child is added in the current users pets node- Brian
        FirebaseDatabase.getInstance().getReference().child("users").child(uid).child("pets").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                //get the value of the pet name from the data snapshot - Brian
                petName = dataSnapshot.child("name").getValue().toString();
                pets.add(petName);
                keys.add(dataSnapshot.getKey());// adds pet profile uid to key array-Brian
                adapter.notifyDataSetChanged();//update the listview-Brian
            }

            //these methods need to exist in order for the child listener to work, however we wont need to use them-Brian
            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

        petProfilesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //get the name and uid of the pet chosen-Brian
                name = pets.get(i);
                key = keys.get(i);
                Intent intent = new Intent(ProfileListActivity.this, ProfileActivity.class);
                //attach the name and key to the intent and send it through to the next activity-Brian
                intent.putExtra("name", name);
                intent.putExtra("key", key);
                startActivity(intent);
            }
        });

        //set up a dialog box so that users can delete profiles-Brian
        petProfilesListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                key = keys.get(i);
                final int petToDelete = i;
                new AlertDialog.Builder(ProfileListActivity.this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Are you sure?")
                        .setMessage("Do you want to delete this note?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                FirebaseDatabase.getInstance().getReference().child("users").child(uid).child("pets").child(key).removeValue();
                                pets.remove(petToDelete);
                                adapter.notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();

                return true;
            }
        });

    }
}


