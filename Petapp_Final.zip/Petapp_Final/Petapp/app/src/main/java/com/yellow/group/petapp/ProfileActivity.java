package com.yellow.group.petapp;

// obviously theres alot of white space on this page so if you think of something to fill it up feel free.-Brian
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

//Todo: delete the note and calendar buttons in the layout since those features were cut-Brian
//Todo: the user textview needs to be fixed in the layout, not positioned properly-Brian

public class ProfileActivity extends AppCompatActivity {

    private TextView tvProfileHeader,user,tvPetWeight,tvPetBreed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        tvProfileHeader = (TextView)findViewById(R.id.tvProfileHeader);
        //set user textview with the current users email-Brian
        user = (TextView)findViewById(R.id.user);
        user.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
        //get current users user id-Brian
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
        //pull the pet name that was selected from the intent-Brian
        String name = getIntent().getStringExtra("name");
        tvProfileHeader.setText(name);

        //pull the uid for the pet selected from the intent-Brian
        String petKey = getIntent().getStringExtra("key");
        tvPetWeight = (TextView)findViewById(R.id.tvPetWeight);
        //tvPetWeight.setText(FirebaseDatabase.getInstance().getReference().child("users").child(uid).child(name).child("weight").toString());
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        //weightRef finds the wight within the database-Brian
        DatabaseReference weightRef = database.getReference().child("users").child(uid).child("pets").child(petKey).child("weight");
        //the event listener listens for any value changes and provides a datasnapshot-Brian
        weightRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String weight = dataSnapshot.getValue().toString();
                tvPetWeight.setText("Pet weight: " + weight);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                //Log.w(Tag,"Failed to read value", databaseError.toException());
                Toast.makeText(ProfileActivity.this, "DataSnapshot failed.", Toast.LENGTH_SHORT).show();
            }
        });

        tvPetBreed = (TextView)findViewById(R.id.tvPetBreed);
        DatabaseReference breedRef = database.getReference().child("users").child(uid).child("pets").child(petKey).child("breed");
        breedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String breed = dataSnapshot.getValue().toString();
                tvPetBreed.setText("Pet breed: " + breed);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                //Log.w(Tag,"Failed to read value", databaseError.toException());
                Toast.makeText(ProfileActivity.this, "DataSnapshot failed.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
