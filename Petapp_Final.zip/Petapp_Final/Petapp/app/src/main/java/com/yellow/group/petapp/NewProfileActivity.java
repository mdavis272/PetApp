package com.yellow.group.petapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class NewProfileActivity extends AppCompatActivity {

    private EditText etPetName, etPetWeight, etPetBreed;
    private Button btCreateProfile;
    private String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_profile);

        etPetName = (EditText)findViewById(R.id.etPetName);
        etPetWeight = (EditText)findViewById(R.id.etPetWeight);
        etPetBreed = (EditText)findViewById(R.id.etPetBreed);
        btCreateProfile = (Button)findViewById(R.id.btCreate);

        //get current users user id-Brian
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();

        btCreateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etPetName.getText().toString();
                String weight = etPetWeight.getText().toString();
                String breed = etPetBreed.getText().toString();

                //if any field is empty, make an error message for user
                if(name.isEmpty() || weight.isEmpty() || breed.isEmpty()) {
                    Toast.makeText(NewProfileActivity.this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
                } else {
                    //put the user's input values into a map with corresponding key-value pairs - Brian
                    Map<String,String> map = new HashMap<String,String>();
                    map.put("name", name);
                    map.put("weight", weight);
                    map.put("breed", breed);

                    //push this map into the current users pets node using their user id- Brian
                    FirebaseDatabase.getInstance().getReference().child("users").child(uid).child("pets").push().setValue(map);

                    //close activity-Brian
                    finish();
                }
            }
        });

    }
}
